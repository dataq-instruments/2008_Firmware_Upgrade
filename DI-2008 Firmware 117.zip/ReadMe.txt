DI-2008 Firmware Update

To update the firmware:
1. Start with the DI-2008 disconnected from your PC
2. Hold down the pushbutton on the side of the DI-2008, and connect the unit to your PC
3. With the DI-2008 connect to the PC, release the button (the mode LED should be solid white)
4. Run the Update.exe application and click the 'Update Firmware' button
5. Once the update is complete, a message will appear indicating that the firmware update completed successfully
6. With the update complete, unplug the USB cable, and plug it back in again
7. The LED will blink green, indicating that you're ready to run the 'DI-2008 Acquisition' software


Revision 1.04 (4/12/2017) 
- Fixes an issue that causes the DI-2008 to reset when connected to a PC, increasing the initial boot period.
- Fixes an issue whereby WinDaq/Unlock codes are erased, removing the ability of the DI-2008 to be daisy-chained to other units for channel expansion.

Revision 1.06 (5/8/2017)
- Fixes a problem that required the DI-2008 to be plugged in after the host PC was booted.

Revision 1.11 (6/30/2017)
- Fixes a problem that causes the DI-2008 to quit scanning due to buffer overflow.
- Change to improve reliablity of ADC reset.
- Added ability to switch USB modes between CDC and libusb without cycling power.
- Fixes a problem that causes a DI-2008 synchronization error due to timer initialization.

Revision 1.12 (12/20/2017)
- Fixes a problem that caused the failure of WinDaq Dashboard to detect a DI-2008 on USB 3.0 ports of computers with Windows7.

Revision 1.13 (1/5/2018)
-Fixes a problem that caused acquisition to fail occasionally

Revision 1.14 (8/6/2019)
-Added support for cjcdelta command
-Includes firmware version 1.12 for ADUCM to fix cjcdelta 
-Change to improve cjcdelta curve in ADUCM

Revision 1.15 (8/6/2019)
-Added commands to support ASCII mode ( encode, eol, deca)
-Added ASCII reporting mode

Revision 1.16 (4/7/2022)
-Added commands to get/set ADuCM model to support ADuCM362/363
-AdcExample.hex must be version 78 or later to support ADuCM362/363
-AdcExample.hex version 78 fixes a bug in info 2 command